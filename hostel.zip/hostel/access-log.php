<html>
    <head><title>Leave Management</title></head>
    <style>
        .leave-apply {
  border: 2px solid black;
  padding: 20px;
  margin: 20px;
  max-width: 500px;
}
body{
    margin: 0;
    padding: 0;
    font-family: montserrat;
        background-image: url(aa.jpg);
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        background-position-x: center;
        border-right: #333;
    height: 100vh;
    overflow: hidden;
}
.leave-apply h2 {
  margin-top: 0;
}

.leave-apply label {
  display: block;
  margin-top: 10px;
}

.leave-apply select, .leave-apply input[type="date"], .leave-apply textarea {
  margin-top: 10px;
  width: 100%;
}

.submit-btn {
  margin-top: 10px;
  background-color: #4CAF50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
body{
  align-content: center;
}

    </style>
    <body >
        <div class="leave-apply">
            <h2>Leave Application</h2>
            <form>
              <label for="student-name">Student Name:</label>
              <input type="text" id="student-name" name="student-name" required>
          
              <label for="room-no">Room No:</label>
              <input type="text" id="room-no" name="room-no" required>
          
              <label for="leave-type">Leave Type:</label>
              <select id="leave-type" name="leave-type" required>
                <option value="" disabled selected>Select Leave Type</option>
                <option value="sick">Emergency Leave</option>
                <option value="personal">Personal Leave</option>
                <option value="vacation">General Leave</option>
                <option value="vacation">On-duty</option>
              </select>
          
              <label for="leave-from">Leave From:</label>
              <input type="date" id="leave-from" name="leave-from" required>
          
              <label for="leave-to">Leave To:</label>
              <input type="date" id="leave-to" name="leave-to" required>
          
              <label for="reason">Reason:</label>
              <textarea id="reason" name="reason" required></textarea>
          
              <button type="submit" class="submit-btn">Submit</button>
            </form>
          </div>          
    </body>
</html>
  